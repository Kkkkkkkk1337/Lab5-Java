package llab1;

public class Calculate extends Thread {
    RecIntegral rec;
    
    public Calculate(RecIntegral rec) {
        this.rec = rec;
    }
    
    public void run() {
        try {
            double result = 0.0;
            rec.N = (rec.B - rec.A) / rec.H;
            int N1 = (int)rec.N;
            for (int i = 0; i < N1; i++) {
               result += (1 / (rec.A + rec.H * i) + 1 /(rec.A + rec.H * (i + 1))) * (rec.H / 2);
               if (rec.N % 1 != 0 ) {
                   double H1= rec.B - (rec.A + rec.H * N1);
                   result += (1 / (rec.A + H1 * i) + 1 /(rec.A + H1 * (i + 1))) * (H1 / 2);
               }
            }
            rec.N = result;
        } catch(Throwable t) {}
    }
}