package llab1;

public class MyException extends Exception {
    MyException(String string) {        
        super(string);
    }
}